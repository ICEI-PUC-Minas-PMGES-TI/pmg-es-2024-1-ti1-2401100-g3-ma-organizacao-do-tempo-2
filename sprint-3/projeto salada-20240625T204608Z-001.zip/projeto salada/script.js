document
	.getElementById("reclameForm")
	.addEventListener("submit", function (event) {
		event.preventDefault();

		const name = document.getElementById("name").value;
		const email = document.getElementById("email").value;
		const phone = document.getElementById("phone").value;
		const message = document.getElementById("message").value;

		const card = document.createElement("div");
		card.classList.add("card");

		const cardBody = document.createElement("div");
		cardBody.classList.add("card-body");

		const esquerdo = document.createElement("div");
		esquerdo.classList.add("left");
		esquerdo.innerHTML = `<strong>Nome:</strong> ${name}<br><strong>E-mail:</strong> ${email}<br><strong>Telefone:</strong> ${phone}`;

		const direito = document.createElement("div");
		direito.classList.add("right");
		direito.innerHTML = `<strong>Mensagem:</strong> ${message}`;

		cardBody.appendChild(esquerdo);
		cardBody.appendChild(direito);
		card.appendChild(cardBody);

		document.getElementById("cardsContainer").appendChild(card);

		// Clear the form
		document.getElementById("reclameForm").reset();
	});
